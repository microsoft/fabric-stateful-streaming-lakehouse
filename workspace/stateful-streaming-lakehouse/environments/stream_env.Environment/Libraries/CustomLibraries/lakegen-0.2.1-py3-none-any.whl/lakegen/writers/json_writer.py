import json
import posixpath
import fsspec
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from .base import BaseWriter


class JsonWriter(BaseWriter):
    """Writer for JSON file output with metadata wrapper"""
    
    def __init__(self, target_folder_uri: str, system_id: int):
        """
        Initialize JSON writer.
        
        Args:
            target_folder_uri: Base folder URI for output
            system_id: System/organization ID for metadata
        """
        self.target_folder_uri = target_folder_uri
        self.system_id = system_id
        self.fs, self._fs_path = fsspec.core.url_to_fs(target_folder_uri)
    
    def write(
        self, 
        table_name: str, 
        data: List[Dict[str, Any]], 
        timestamp: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        Write data to JSON file.
        
        Args:
            table_name: Name of the table
            data: List of records to write
            timestamp: Optional timestamp for filename (defaults to current time)
            
        Returns:
            File URI of written file
        """
        import time
        
        if timestamp is None:
            timestamp = int(time.time() * 1000)
        
        # Add standard columns
        data = self._add_standard_columns(data)
        
        table_folder_uri = posixpath.join(self.target_folder_uri, table_name)
        file_uri = posixpath.join(table_folder_uri, f"{table_name}_{timestamp}.json")
        
        payload = {
            "_meta": {
                "schemaVersion": "1.0",
                "producer": "lakegen.mcmillan",
                "recordType": table_name,
                "enqueuedTime": self._now_utc_iso(),
            },
            "data": data,
        }
        
        with fsspec.open(file_uri, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        
        return file_uri
    
    def _add_standard_columns(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Add standard metadata columns to each record."""
        timestamp = self._now_utc_iso()
        for record in data:
            record["OrganizationId"] = self.system_id
            record["GeneratedAt"] = timestamp
        return data
    
    def _now_utc_iso(self) -> str:
        """Get current UTC timestamp in ISO format."""
        return datetime.now(timezone.utc).isoformat()
    
    def close(self):
        """No cleanup needed for JSON writer"""
        pass
