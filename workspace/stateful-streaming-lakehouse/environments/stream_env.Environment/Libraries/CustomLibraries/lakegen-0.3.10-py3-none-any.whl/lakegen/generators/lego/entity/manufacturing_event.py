import hashlib
import random
import uuid
from datetime import datetime, timedelta

import numpy as np


MACHINE_IDS = [f"INJ-{i:03d}" for i in range(1, 21)]

DEFECT_TYPES = ["flash", "short_shot", "sink_mark", "warp", "burn_mark", "color_streak"]

# Common LEGO color IDs with higher selection weights
_COMMON_COLOR_IDS = {0, 15, 4, 1, 14, 7, 6, 5, 71, 72}

# Shift windows: (start_hour, end_hour)
_SHIFTS = [(6, 14), (14, 22), (22, 6)]


def _machine_seed(machine_id: str) -> int:
    return int(hashlib.md5(machine_id.encode()).hexdigest(), 16) & 0xFFFFFFFF


def _machine_params(machine_id: str) -> dict:
    """Deterministic per-machine baseline parameters."""
    rng = random.Random(_machine_seed(machine_id))
    machine_index = MACHINE_IDS.index(machine_id) if machine_id in MACHINE_IDS else 0
    # Older machines (lower index) drift higher and have more defects
    age_factor = 1.0 - (machine_index / len(MACHINE_IDS))
    return {
        "mold_temp_base": rng.uniform(225, 235),
        "injection_pressure_base": rng.uniform(750, 850),
        "defect_rate": 0.03 + age_factor * 0.05,  # 3-8%
    }


def _weighted_color_id(colors_catalog: list) -> int:
    """Select a color with heavy weighting toward common LEGO colors."""
    weights = []
    for c in colors_catalog:
        cid = c.get("id", c.get("ColorId", 0))
        weights.append(10.0 if cid in _COMMON_COLOR_IDS else 1.0)
    chosen = random.choices(colors_catalog, weights=weights, k=1)[0]
    return int(chosen.get("id", chosen.get("ColorId", 0)))


def _zipf_machine_weights(n: int, alpha: float = 1.3) -> list:
    """Zipf-distributed weights so some machines are much busier."""
    ranks = np.arange(1, n + 1, dtype=float)
    weights = 1.0 / np.power(ranks, alpha)
    return (weights / weights.sum()).tolist()


def _shift_timestamp(base_date: datetime) -> datetime:
    """Generate a timestamp clustered within a random 8-hour shift window."""
    shift_start, shift_end = random.choice(_SHIFTS)
    if shift_end < shift_start:
        # Overnight shift
        shift_start_dt = base_date.replace(hour=shift_start, minute=0, second=0, microsecond=0)
        shift_duration_h = (24 - shift_start) + shift_end
    else:
        shift_start_dt = base_date.replace(hour=shift_start, minute=0, second=0, microsecond=0)
        shift_duration_h = shift_end - shift_start

    offset_sec = random.gauss(shift_duration_h * 3600 / 2, shift_duration_h * 3600 / 6)
    offset_sec = max(0, min(offset_sec, shift_duration_h * 3600))
    return shift_start_dt + timedelta(seconds=offset_sec)


class ManufacturingEvent:
    def __init__(self, production_lines: list = None):
        if production_lines:
            # Use real production line IDs (injection_molding lines only)
            self._machine_ids = [
                l["LineId"] for l in production_lines
                if l.get("CellType") == "injection_molding"
            ] or [l["LineId"] for l in production_lines]
        else:
            self._machine_ids = MACHINE_IDS
        self._machine_weights = _zipf_machine_weights(len(self._machine_ids))

    def _pick_machine(self) -> str:
        return random.choices(self._machine_ids, weights=self._machine_weights, k=1)[0]

    def _build_event(
        self,
        timestamp: datetime,
        machine_id: str,
        part_num: str,
        color_id: int,
        batch_id: str,
        production_order_id: str = None,
    ) -> dict:
        params = _machine_params(machine_id)

        mold_temp = round(float(np.random.normal(params["mold_temp_base"], 3)), 1)
        injection_pressure = round(float(np.random.normal(params["injection_pressure_base"], 30)), 1)
        cycle_time_ms = int(np.random.normal(12000, 2000))

        defect_detected = random.random() < params["defect_rate"]
        defect_type = random.choice(DEFECT_TYPES) if defect_detected else None

        return {
            "EventId": str(uuid.uuid4()),
            "Timestamp": timestamp.isoformat(),
            "MachineId": machine_id,
            "PartNum": part_num,
            "ColorId": int(color_id),
            "MoldTemp": mold_temp,
            "InjectionPressure": injection_pressure,
            "CycleTimeMs": cycle_time_ms,
            "DefectDetected": defect_detected,
            "DefectType": defect_type,
            "BatchId": batch_id,
            "ProductionOrderId": production_order_id,
        }

    def _generate_events(self, parts_catalog: list, colors_catalog: list, count: int = 10) -> list:
        """Generate standalone/background noise events with shift-aware timestamps."""
        events = []
        base_date = datetime.now() - timedelta(hours=random.randint(1, 24))
        batch_date = base_date.strftime("%Y%m%d")
        batch_seq = random.randint(1, 999)
        batch_id = f"B-{batch_date}-{batch_seq:03d}"

        for _ in range(count):
            timestamp = _shift_timestamp(base_date)

            part = random.choice(parts_catalog)
            part_num = part.get("part_num", part.get("PartNum"))
            color_id = _weighted_color_id(colors_catalog)
            machine_id = self._pick_machine()

            event = self._build_event(
                timestamp=timestamp,
                machine_id=machine_id,
                part_num=part_num,
                color_id=color_id,
                batch_id=batch_id,
                production_order_id=None,
            )
            events.append(event)

        return events

    def _generate_events_for_order(self, production_order: dict, count: int = None) -> list:
        """Generate events linked to a specific production order.

        Args:
            production_order: Dict with keys like ProductionOrderId, PartNum,
                ColorId, MachineId (LineId), Quantity, ActualStart, ActualEnd.
            count: Number of events. Defaults to ~1 per 500 parts (min 5, max 200).
        """
        order_id = production_order["ProductionOrderId"]
        part_num = production_order["PartNum"]
        color_id = int(production_order["ColorId"])
        machine_id = production_order.get("MachineId", production_order.get("LineId", self._pick_machine()))

        quantity = production_order.get("TargetQuantity", production_order.get("Quantity", 5000))
        if count is None:
            count = max(10, min(200, quantity // 500))

        # Parse time window
        actual_start = production_order.get("ActualStart")
        actual_end = production_order.get("ActualEnd")
        if isinstance(actual_start, str):
            actual_start = datetime.fromisoformat(actual_start)
        if isinstance(actual_end, str):
            actual_end = datetime.fromisoformat(actual_end)

        if actual_start is None:
            actual_start = datetime.now() - timedelta(hours=8)
        if actual_end is None:
            actual_end = actual_start + timedelta(hours=8)

        duration_sec = (actual_end - actual_start).total_seconds()
        batch_date = actual_start.strftime("%Y%m%d")
        batch_seq = random.randint(1, 999)
        batch_id = f"B-{batch_date}-{batch_seq:03d}"

        events = []
        for i in range(count):
            # Distribute timestamps across the production window with slight jitter
            progress = i / max(count - 1, 1)
            offset_sec = progress * duration_sec + random.gauss(0, duration_sec * 0.01)
            offset_sec = max(0, min(offset_sec, duration_sec))
            timestamp = actual_start + timedelta(seconds=offset_sec)

            event = self._build_event(
                timestamp=timestamp,
                machine_id=machine_id,
                part_num=part_num,
                color_id=color_id,
                batch_id=batch_id,
                production_order_id=order_id,
            )
            events.append(event)

        return events
